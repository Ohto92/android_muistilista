package com.example.tapsa.muista;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Valmis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_valmis);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
    }
}
