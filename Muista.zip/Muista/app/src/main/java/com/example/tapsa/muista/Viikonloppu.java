package com.example.tapsa.muista;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class Viikonloppu extends AppCompatActivity {

    CheckBox cb,cb1, cb2, cb3, cb4, cb5, cb6;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viikonloppu);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        cb= (CheckBox) findViewById(R.id.checkBox);
        cb1= (CheckBox) findViewById(R.id.checkBox1);
        cb2= (CheckBox) findViewById(R.id.checkBox2);
        cb3= (CheckBox) findViewById(R.id.checkBox3);
        cb4= (CheckBox) findViewById(R.id.checkBox4);
        cb5= (CheckBox) findViewById(R.id.checkBox5);
        cb6= (CheckBox) findViewById(R.id.checkBox6);

        text=(TextView) findViewById(R.id.textView3);



    }




    public void checkone(View v)
    {
        if(cb.isChecked()&& cb1.isChecked() && cb2.isChecked() && cb3.isChecked()&&cb4.isChecked()&& cb5.isChecked() && cb6.isChecked())
        {
            text.setText("Olet valmis lähtemään");
            //Intent intent= new Intent(this, DisplayMessageActivity.class);
            //startActivity(intent);
            Intent intent = new Intent(this, Valmis.class);
            startActivity(intent);
        }
        else if(cb.isChecked()&& cb1.isChecked() && cb2.isChecked() && cb3.isChecked())
        {
            text.setText("Muista tavarat");
        }
        else if(cb4.isChecked()&& cb5.isChecked() && cb6.isChecked())
        {
            text.setText("Muista tarkastaa asunto");
        }


        else
        {
            text.setText("Et ole valmis lähtemään");
        }

    }
}